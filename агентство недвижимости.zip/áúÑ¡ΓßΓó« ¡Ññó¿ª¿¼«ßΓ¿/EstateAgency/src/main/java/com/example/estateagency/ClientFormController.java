package com.example.estateagency;

import com.dlsc.formsfx.model.util.ResourceBundleService;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Window;

import java.net.URL;
import java.sql.*;
import java.util.List;
import java.util.ResourceBundle;

public class ClientFormController implements Initializable {
    @FXML
    private TableView<Estate> estateTableView;
    @FXML
    private TableColumn idColumn;
    @FXML
    private TableColumn addressColumn;
    @FXML
    private TableColumn roomsColumn;
    @FXML
    private TableColumn floorColumn;
    @FXML
    private TableColumn costColumn;
    @FXML
    private TableColumn balconyColumn;

    @FXML
    private TableView<Estate> wishlistTableView;
    @FXML
    private TableColumn idColumn1;
    @FXML
    private TableColumn addressColumn1;
    @FXML
    private TableColumn roomsColumn1;
    @FXML
    private TableColumn floorColumn1;
    @FXML
    private TableColumn costColumn1;
    @FXML
    private TableColumn balconyColumn1;

    @FXML
    private Label lblClientInfo;
    @FXML
    private Button btnAddToWishlist;
    @FXML
    private Button btnRemoveFromWishlist;

    private Client client;
    private List<Estate> estates;
    private DB db;

    public ClientFormController(DB db, Client client, List<Estate> estates) {
        setClient(client);
        setEstates(estates);
        this.db = db;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public void setEstates(List<Estate> estates) {
        this.estates = estates;
    }

    @FXML
    private void initForm() {
        lblClientInfo.setText(client.toString());

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        roomsColumn.setCellValueFactory(new PropertyValueFactory<>("rooms"));
        floorColumn.setCellValueFactory(new PropertyValueFactory<>("numFloor"));
        costColumn.setCellValueFactory(new PropertyValueFactory<>("cost"));
        balconyColumn.setCellValueFactory(new PropertyValueFactory<>("haveBalcony"));
        ObservableList<Estate> oList = FXCollections.observableArrayList(estates);
        estateTableView.setItems(oList);

        idColumn1.setCellValueFactory(new PropertyValueFactory<>("id"));
        addressColumn1.setCellValueFactory(new PropertyValueFactory<>("address"));
        roomsColumn1.setCellValueFactory(new PropertyValueFactory<>("rooms"));
        floorColumn1.setCellValueFactory(new PropertyValueFactory<>("numFloor"));
        costColumn1.setCellValueFactory(new PropertyValueFactory<>("cost"));
        balconyColumn1.setCellValueFactory(new PropertyValueFactory<>("haveBalcony"));
        ObservableList<Estate> oListWish = FXCollections.observableArrayList(client.getWishlist());
        wishlistTableView.setItems(oListWish);
    }

    @FXML
    private void onAddToWishlist() throws SQLException {
        Estate selEstate = estateTableView.getSelectionModel().getSelectedItem();
        if (selEstate != null) {
            List<Estate> list = client.getWishlist();
            if (list.contains(selEstate)) {
                showAlert(Alert.AlertType.ERROR, null, "Добавление в избранное", "Операция невозможна");
                return;
            }

            wishlistTableView.getItems().add(selEstate);
            client.addToWishlist(selEstate);

            db.insertToWishlist(client.getId(), selEstate.getId());
        }
    }

    @FXML
    private void onRemoveFromWishlist() throws SQLException {
        Estate selEstate = wishlistTableView.getSelectionModel().getSelectedItem();
        if (selEstate != null) {
            wishlistTableView.getItems().remove(selEstate);
            client.removeFromWishlist(selEstate);

            db.removeFromWishlist(client.getId(), selEstate.getId());
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initForm();
    }

    public static void infoBox(String infoMessage, String headerText, String title) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText(infoMessage);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.showAndWait();
    }

    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
}
