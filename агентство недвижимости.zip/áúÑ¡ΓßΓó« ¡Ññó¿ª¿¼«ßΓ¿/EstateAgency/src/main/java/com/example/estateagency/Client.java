package com.example.estateagency;

import java.util.ArrayList;
import java.util.List;

public class Client {
    private int id;
    private String firstName;
    private String secondName;
    private String phone;

    private List<Estate> wishlist;

    public Client(int id, String fName, String sName, String phone) {
        this.id = id;
        firstName = fName;
        secondName = sName;
        this.phone = phone;
        wishlist = new ArrayList<>();
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public String getPhone() {
        return phone;
    }

    public void setWishlist(List<Estate> value) {
        wishlist = value;
    }

    public List<Estate> getWishlist() { return wishlist; }

    public void addToWishlist(Estate estate) {
        wishlist.add(estate);
    }

    public void removeFromWishlist(Estate estate) {
        wishlist.remove(estate);
    }

    @Override
    public String toString() {
        return String.format("%s %s (Телефон: %s)",firstName, secondName, phone);
    }

    public int getId() {
        return id;
    }
}
