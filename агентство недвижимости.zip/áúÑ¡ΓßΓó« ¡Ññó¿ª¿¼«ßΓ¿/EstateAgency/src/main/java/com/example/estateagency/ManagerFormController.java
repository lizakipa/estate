package com.example.estateagency;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Window;

import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

public class ManagerFormController implements Initializable {
    @FXML
    private TableView<LikesObject> likesTableView;
    @FXML
    private TableColumn idFullNameClientColumn;
    @FXML
    private TableColumn idPhoneColumn;
    @FXML
    private TableColumn idLikeAddressColumn;
    @FXML
    private Label lblManagerInfo;

    private Manager manager;
    private List<LikesObject> listLikes;
    private DB db;

    public ManagerFormController(DB db, Manager manager, List<LikesObject> likes) {
        this.manager = manager;
        listLikes = likes;
        this.db = db;
    }

    @FXML
    private void initForm() {
        lblManagerInfo.setText(manager.toString());

        idPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        idFullNameClientColumn.setCellValueFactory(new PropertyValueFactory<>("fullnameClient"));
        idLikeAddressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        ObservableList<LikesObject> oList = FXCollections.observableArrayList(listLikes);
        likesTableView.setItems(oList);
    }

    @FXML
    private void onSignOrder() throws SQLException {
        LikesObject likesObject = likesTableView.getSelectionModel().getSelectedItem();
        if (likesObject != null) {
            //db.removeClient(likesObject.getClientID());
            db.removeEstate(likesObject.getEstateID());
            db.updateSold(manager.getId());

            lblManagerInfo.setText(manager.toString());
            if (listLikes.contains(likesObject)) {
                listLikes.remove(likesObject);
                likesTableView.getItems().remove(likesObject);
                manager.increaseSold();
                return;
            }
        }
    }

    //
//    @FXML
//    private void onRemoveFromWishlist() throws SQLException {
//        Estate selEstate = wishlistTableView.getSelectionModel().getSelectedItem();
//        if (selEstate != null) {
//            wishlistTableView.getItems().remove(selEstate);
//            client.removeFromWishlist(selEstate);
//
//            db.removeFromWishlist(client.getId(), selEstate.getId());
//        }
//    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initForm();
    }

    public static void infoBox(String infoMessage, String headerText, String title) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText(infoMessage);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.showAndWait();
    }

    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
}
