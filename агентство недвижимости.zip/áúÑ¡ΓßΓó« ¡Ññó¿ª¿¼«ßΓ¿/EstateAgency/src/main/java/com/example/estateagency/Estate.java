package com.example.estateagency;

import java.util.Objects;

public class Estate {
    private int id;
    private String address;
    private int rooms;
    private int numFloor;
    private int cost;
    private boolean haveBalcony;

    public Estate() {}
    public Estate(int id, String address, int rooms, int numFloor, int cost, boolean haveBalcony) {
        this.address = address;
        this.rooms = rooms;
        this.numFloor = numFloor;
        this.cost = cost;
        this.haveBalcony = haveBalcony;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getRooms() {
        return rooms;
    }

    public void setRooms(int rooms) {
        this.rooms = rooms;
    }

    public int getNumFloor() {
        return numFloor;
    }

    public void setNumFloor(int numFloor) {
        this.numFloor = numFloor;
    }

    public int getCost() {
        return cost;
    }

    public boolean isHaveBalcony() {
        return haveBalcony;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public void setHaveBalcony(boolean haveBalcony) {
        this.haveBalcony = haveBalcony;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Estate estate = (Estate) o;
        //return address.equals(estate.address);
        return id == estate.getId();
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
