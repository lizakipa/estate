package com.example.estateagency;

public class Manager {
    private int id;
    private String firstName;
    private String secondName;
    private int countSold;

    public Manager(int id, String fName, String sName, int countSold) {
        this.id = id;
        firstName = fName;
        secondName = sName;
        this.countSold = countSold;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public void setCountSold(int countSold) {
        this.countSold = countSold;
    }

    public int getCountSold() {
        return countSold;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    @Override
    public String toString() {
        return String.format("%s %s (Количество продаж: %d)",firstName, secondName, countSold);
    }

    public void increaseSold() { ++countSold; }

    public int getId() {
        return id;
    }
}
