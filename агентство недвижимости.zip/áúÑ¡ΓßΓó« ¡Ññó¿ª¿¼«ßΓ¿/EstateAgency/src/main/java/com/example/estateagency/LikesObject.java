package com.example.estateagency;

public class LikesObject {
    private int clientID;
    private int estateID;
    private String fullnameClient;
    private String phone;
    private String address;

    public LikesObject(int clientID, int estateID, String fullnameClient, String phone, String address) {
        this.clientID = clientID;
        this.estateID = estateID;
        this.fullnameClient = fullnameClient;
        this.phone = phone;
        this.address = address;
    }

    public int getClientID() {
        return clientID;
    }

    public void setClientID(int clientID) {
        this.clientID = clientID;
    }

    public int getEstateID() {
        return estateID;
    }

    public void setEstateID(int estateID) {
        this.estateID = estateID;
    }

    public String getFullnameClient() {
        return fullnameClient;
    }

    public void setFullnameClient(String fullnameClient) {
        this.fullnameClient = fullnameClient;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
