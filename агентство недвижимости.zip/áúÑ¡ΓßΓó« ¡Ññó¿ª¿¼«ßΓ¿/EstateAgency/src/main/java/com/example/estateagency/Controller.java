package com.example.estateagency;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class Controller {

    @FXML
    private TextField loginField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button submitButton;

    @FXML
    private CheckBox pass_toggle;

    @FXML
    private TextField passwordHidden;

    @FXML
    private Canvas canvas;

    int enter_counter = 0;

    @FXML
    //Метод для авторизации
    public void login(ActionEvent event) throws SQLException, IOException, ClassNotFoundException {

        Window owner = submitButton.getScene().getWindow();

        if (loginField.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                    "Please enter your login");
            return;
        }
        if (passwordField.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                    "Please enter a password");
            return;
        }

        String login = loginField.getText();
        String password = passwordField.getText();

        DB db = new DB();
        ConnectResult conResult = db.validate(login, password);
        switch (conResult.getLoginResult()) {
            case Manager -> managerMode(db, conResult.getId());
            case Client -> clientMode(db, conResult.getId());
            case Unknown -> retryConnect();
        }
    }

    public void clientMode(DB db, int id) throws IOException, SQLException {
        Client client = db.getClient(id);
        List<Estate> estates = db.getAllEstates();

        FXMLLoader loader = new FXMLLoader();
        loader.setController(new ClientFormController(db, client, estates));
        loader.setLocation(Controller.class.getResource("client.fxml"));
        Parent root = loader.load();

        Stage stage = new Stage();
        stage.setTitle("Кабинет клиента");
        stage.setScene(new Scene(root, 800, 600));

        stage.show();
        stage.setResizable(false);

//            db.getUpdate(login);
//
//
//            ((Node)(event.getSource())).getScene().getWindow().hide();
    }

    public static void managerMode(DB db, int id) throws SQLException, IOException {
        Manager manager = db.getManager(id);
        List<LikesObject> likesObjects = db.getAllLikes();

        FXMLLoader loader = new FXMLLoader();
        loader.setController(new ManagerFormController(db, manager, likesObjects ));
        loader.setLocation(Controller.class.getResource("manager.fxml"));
        Parent root = loader.load();

        Stage stage = new Stage();
        stage.setTitle("Кабинет менеджера");
        stage.setScene(new Scene(root, 800, 600));

        stage.show();
        stage.setResizable(false);
    }

    public void retryConnect() {
        if(enter_counter>1){
            new Thread(()->{
                submitButton.setDisable(true);
                try {
                    Thread.sleep(3000);
                    submitButton.setDisable(false);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
        }
        infoBox("Please enter correct Login and Password", null, "Failed");
        System.out.println("counter: "+enter_counter);
        enter_counter++;
    }

    public static void infoBox(String infoMessage, String headerText, String title) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText(infoMessage);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.showAndWait();
    }
    //Метод показа предупреждений
    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

    @FXML
    //Метод для возможности просмотра зашифрованного пароля
    public void togglevisiblePassword(ActionEvent event) {
        if (pass_toggle.isSelected()) {
            passwordHidden.setText(passwordField.getText());
            passwordHidden.setVisible(true);
            passwordField.setVisible(false);
            return;
        }
        passwordField.setText(passwordHidden.getText());
        passwordField.setVisible(true);
        passwordHidden.setVisible(false);
    }
}