package com.example.estateagency;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

class ConnectResult {
    public LoginResult getLoginResult() {
        return loginResult;
    }

    public int getId() {
        return id;
    }

    public enum LoginResult {Unknown, Client, Manager};
    private LoginResult loginResult;
    private int id;

    public ConnectResult(LoginResult result, int id) {
        loginResult = result;
        this.id = id;
    }
}

public class DB {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/estate_agency";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "mysql1987";
    private static final String SELECT_VALIDATE  = "SELECT * FROM `login_password` WHERE login = ? and password = ?";
    private static final String SELECT_CLIENT_BY_ID = "SELECT *FROM `client` WHERE client.id = ?";
    private static final String SELECT_MANAGER_BY_ID = "SELECT *FROM `manager` WHERE manager.id = ?";
    private static final String SELECT_WISHLIST_CLIENT = "SELECT *FROM `estate`" +
            " INNER JOIN `wishlist` ON estate.id=wishlist.estate_id AND client_id = ?";
    private static final String SELECT_ALL_ESTATES = "SELECT *FROM `estate`";
    private static final String SELECT_ESTATE_BY_ID = "SELECT *FROM `estate` WHERE client.id = ?";
    private static final String INSERT_TO_WISHLIST = "INSERT INTO `wishlist` (client_id, estate_id) VALUES (?, ?)";
    private static final String REMOVE_FROM_WISHLIST = "DELETE FROM `wishlist` WHERE client_id = ? and estate_id = ?";
    private static final String REMOVE_CLIENT = "DELETE FROM `client` WHERE id = ?";
    private static final String REMOVE_ESTATE = "DELETE FROM `estate` WHERE id = ?";
    private static final String UPDATE_SOLD = "UPDATE `manager` SET count_sold=count_sold+1 WHERE id = ?";
    private static final String SELECT_WISHLIST_CLIENT_ESTATE = "SELECT client.id, estate.id, client.first_name, " +
            "client.second_name , client.phone, estate.address " +
            "FROM client " +
            "INNER JOIN wishlist ON client.id = wishlist.client_id " +
            "INNER JOIN estate ON estate.id=wishlist.estate_id";

    //Метод проверки введенных пароля и логина на соответствие с данными из бд
    public ConnectResult validate(String login, String password) throws SQLException, ClassNotFoundException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_VALIDATE);
            preparedStatement.setString(1, login);
            preparedStatement.setString(2, password);

            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                int clientId = rs.getInt("client_log_id");
                int managerId = rs.getInt("manager_log_id");

                if (clientId != 0)
                    return new ConnectResult(ConnectResult.LoginResult.Client, clientId);
                else
                    return new ConnectResult(ConnectResult.LoginResult.Manager, managerId);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }

        return new ConnectResult(ConnectResult.LoginResult.Unknown, -1);
    }

    public void removeClient(int id) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            PreparedStatement preparedStatement = connection.prepareStatement(REMOVE_CLIENT);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeEstate(int id) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            PreparedStatement preparedStatement = connection.prepareStatement(REMOVE_ESTATE);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateSold(int id) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_SOLD);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Метод для получения информации о клиенте
    public Client getClient(int id) throws SQLException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_CLIENT_BY_ID);
            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int idClient = resultSet.getInt(1);
                String fName= resultSet.getString(2);
                String sName = resultSet.getString(3);
                String phone = resultSet.getString(4);
                Client client = new Client(idClient, fName, sName, phone);
                client.setWishlist(getWishlist(connection, id));

                return client;
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return null;
    }

    public Manager getManager(int id) throws SQLException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_MANAGER_BY_ID);
            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int idManager = resultSet.getInt(1);
                String fName= resultSet.getString(2);
                String sName = resultSet.getString(3);
                int calls = resultSet.getInt(4);
                Manager manager = new Manager(idManager, fName, sName, calls);

                return manager;
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return null;
    }

    public List<Estate> getAllEstates() throws SQLException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_ESTATES);

            ResultSet resSet = preparedStatement.executeQuery();
            List<Estate> estates = new ArrayList<>();
            while (resSet.next()) {
                int idEstate = resSet.getInt(1);
                String address = resSet.getString(2);
                int rooms = resSet.getInt(3);
                int floor = resSet.getInt(4);
                int cost = resSet.getInt(5);
                boolean balcony = resSet.getBoolean(6);
                estates.add(new Estate(idEstate, address, rooms, floor, cost, balcony));
            }

            return estates;
        }
    }

    public List<LikesObject> getAllLikes() throws SQLException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_WISHLIST_CLIENT_ESTATE);

            ResultSet resSet = preparedStatement.executeQuery();
            List<LikesObject> likes = new ArrayList<>();
            while (resSet.next()) {
                int clientId = resSet.getInt(1);
                int estateId = resSet.getInt(2);
                String fName = resSet.getString(3);
                String sName = resSet.getString(4);
                String phone = resSet.getString(5);
                String address = resSet.getString(6);

                likes.add(new LikesObject(clientId, estateId, fName + " " + sName, phone, address));
            }

            return likes;
        }
    }

    public List<Estate> getWishlist(Connection connection, int id) throws SQLException {
        PreparedStatement prepStateWishlist = connection.prepareStatement(SELECT_WISHLIST_CLIENT);
        prepStateWishlist.setInt(1, id);
        ResultSet resWishlist = prepStateWishlist.executeQuery();
        List<Estate> estates = new ArrayList<>();
        while (resWishlist.next()) {
            int idEstate = resWishlist.getInt(1);
            String address = resWishlist.getString(2);
            int rooms = resWishlist.getInt(3);
            int floor = resWishlist.getInt(4);
            int cost = resWishlist.getInt(5);
            boolean balcony = resWishlist.getBoolean(6);
            estates.add(new Estate(idEstate, address, rooms, floor, cost, balcony));
        }

        return estates;
    }

    public void insertToWishlist(int idClient, int idEstate) throws SQLException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_TO_WISHLIST);
            preparedStatement.setInt(1, idClient);
            preparedStatement.setInt(2, idEstate);
            preparedStatement.executeUpdate();

        }
    }

    public void removeFromWishlist(int idClient, int idEstate) throws SQLException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            PreparedStatement preparedStatement = connection.prepareStatement(REMOVE_FROM_WISHLIST);
            preparedStatement.setInt(1, idClient);
            preparedStatement.setInt(2, idEstate);
            preparedStatement.executeUpdate();
        }
    }

    //Вывод sql ошибок
    public static void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}